package xxx.yyy;
import com.thinking.machines.annotations.*;
@Path("/test")
public class Test
{
@Path("/test1")
@ResponseType("text/html")
@Secured("xxx.yyy.check")
public String doSomething()
{
System.out.println("doSomething chala");

return "God is great.I live in Ujjain";

}
}