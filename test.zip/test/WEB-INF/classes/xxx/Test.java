package xxx.yyy;
import com.thinking.machines.annotations.*;
@Path("/test")
public class Test
{
@Path("/test1")
@ResponseType("none")
@Secured("xxx.yyy.Check")
public void doSomething()
{
System.out.println("doSomething chala");
}
}